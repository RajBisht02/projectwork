<?php
    $name = $_POST['name'];
    $genre = $_POST['genre'];
    $instagram = $_POST['instagram'];
    $email = $_POST['email'];


    // Database connection
    $conn = new mysqli('localhost','root','','test');
    if($conn->connect_error){
        echo "$conn->connect_error";
        die("Connection Failed : ". $conn->connect_error);
    } else {
        $stmt = $conn->prepare("insert into you(name, genre, instagram, email ) values(?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $genre, $instagram, $email);
        $execval = $stmt->execute();
        echo $execval;
        echo "Information successful...";
        header("Location: after.html"); 
        $stmt->close();
        $conn->close();
    }
?>